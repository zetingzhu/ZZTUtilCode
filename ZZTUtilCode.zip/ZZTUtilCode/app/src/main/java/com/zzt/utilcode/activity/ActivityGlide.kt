package com.zzt.utilcode.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.zzt.utilcode.R

/**
 *
 * Created by zeting
 * Date 2019-07-31.
 */
class ActivityGlide : AppCompatActivity(){


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)



        setContentView(R.layout.activity_glide)
    }

}