package com.zzt.activity.imp;

/**
 * @author: zeting
 * @date: 2021/3/17
 */
public interface DefaultActivityAddImp {

}
